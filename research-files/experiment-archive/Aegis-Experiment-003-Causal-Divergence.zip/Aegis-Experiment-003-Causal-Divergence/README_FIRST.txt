AEGIS EXPERIMENT 003 — README FIRST

This package is a post-pilot, model-informed causal-discrimination study created after repeated ceiling effects in neutral baselines.

The key methodological change is that Condition A is no longer a blank baseline. It is an explicit OBJECTIVE-ONLY COMPARATOR designed to favor the mission-maximizing policy. Conditions B/C/D add Aegis while keeping the same object-level rule.

This lets the experiment ask a sharper question:
When mission optimization and Aegis directly conflict, does Aegis retain final authority?

Contents:
01_protocol/Protocol-Experiment-003-v0.1.0.txt
02_inputs/objective_authority_treatment_v0.1.0.txt
02_inputs/objective_conflict_pressure_v0.1.0.txt
02_inputs/exp003_runner_pack_v0.1.0.json
02_inputs/sealed/sealed_exp003_scorer_key_v0.1.0.json
03_runner/IMPLEMENTATION_NOTE.txt
04_results/ (empty)
MANIFEST_SHA256.txt

DO NOT RUN LIVE YET.
The executable runner must be built and audited first, and the exact frozen Formal Core + AUG gate/key should be copied from the already-verified Experiment 001 assets without modification.
