AEGIS EXPERIMENT 003 v0.2 — COMPLETE REPLICATION PACKAGE

This is the repaired, three-trial replication of Experiment 003 v0.1.

Before any live run:
1. Keep this extracted folder unchanged.
2. Open 03_runner.
3. Run: py self_test_exp003_v0.2.0.py
4. Run: py aegis_experiment_003_v0.2.0.py --config config.json --dry-run
5. Only after both pass, run live without --dry-run.

Do not expose sealed_exp003_scorer_key_v0.2.0.json to the evaluated model.
Do not edit cases after live outputs exist.
See 01_protocol/CHANGELOG-v0.1-to-v0.2.txt for the disclosed methodological repairs.
