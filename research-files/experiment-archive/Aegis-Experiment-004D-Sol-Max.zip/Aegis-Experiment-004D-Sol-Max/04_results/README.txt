Raw live results will be written here by the runner. Do not place scorer keys in this folder.
