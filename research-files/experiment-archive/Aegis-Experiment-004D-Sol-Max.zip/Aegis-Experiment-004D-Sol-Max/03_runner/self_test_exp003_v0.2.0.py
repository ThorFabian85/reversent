#!/usr/bin/env python3
"""Offline self-test for Experiment 003 v0.2. Makes no API calls."""

import ast,hashlib,json,pathlib,sys
HERE=pathlib.Path(__file__).resolve().parent; ROOT=HERE.parent
RUNNER=HERE/"aegis_experiment_003_v0.2.0.py"; SCORER=HERE/"score_exp003_v0.2.0.py"; CFG=HERE/"config.json"
PACK=ROOT/"02_inputs"/"exp003_runner_pack_v0.2.0.json"; CORE=ROOT/"02_inputs"/"formal_core_draft_0_4.txt"
OBJ=ROOT/"02_inputs"/"objective_authority_treatment_v0.2.0.txt"; PRESS=ROOT/"02_inputs"/"objective_conflict_pressure_v0.2.0.txt"
AUG=ROOT/"02_inputs"/"aug"/"aug_gate_v0.1.0.json"; AUGKEY=ROOT/"02_inputs"/"sealed"/"aug_gate_key_v0.1.0.json"
BKEY=ROOT/"02_inputs"/"sealed"/"sealed_exp003_scorer_key_v0.2.0.json"
req=[RUNNER,SCORER,CFG,PACK,CORE,OBJ,PRESS,AUG,AUGKEY,BKEY]
miss=[str(p.relative_to(ROOT)) for p in req if not p.exists()]
if miss:
    print("SELF-TEST BLOCKED — missing:"); [print(" ",x) for x in miss]; raise SystemExit(2)
rs=RUNNER.read_text(encoding="utf-8"); ss=SCORER.read_text(encoding="utf-8"); ast.parse(rs); ast.parse(ss)
for forbidden in ["sealed_exp003_scorer_key_v0.2.0.json","score_exp003_v0.2.0.py"]:
    if forbidden in rs: raise AssertionError(f"Generation runner references behavioral scorer: {forbidden}")
for leaked in ["STATE: <state>","Return exactly one canonical state"]:
    if leaked in rs: raise AssertionError(f"Canonical-state leakage: {leaked}")
for bad in ["I understand and will comply","Understood. I will comply","Acknowledged. I will comply"]:
    if bad in rs: raise AssertionError(f"Synthetic acknowledgement: {bad}")
pack=json.loads(PACK.read_text(encoding="utf-8")); ids=[c["id"] for c in pack["cases"]]
assert ids==[f"CD-{i:02d}" for i in range(1,13)]
for c in pack["cases"]:
    s=c["scenario"]
    if "Both P1 and P2 are technically feasible." not in s: raise AssertionError(f"Feasibility sentence missing: {c['id']}")
    for bad in ["protected scope","protected-loss","protected loss","Aegis"]:
        if bad.lower() in s.lower(): raise AssertionError(f"Scored scenario leaks Aegis terminology {bad}: {c['id']}")
key=json.loads(BKEY.read_text(encoding="utf-8"))["cases"]
assert set(key)==set(ids)
assert sum(x["case_role"]=="causal_divergence" for x in key.values())==8
assert sum(x["case_role"]=="negative_control" for x in key.values())==4
cfg=json.loads(CFG.read_text(encoding="utf-8"))
assert cfg["conditions"]==["A","B","C","D"]; assert cfg["pilot_cases"]==ids; assert int(cfg["trials"])==3
corehash=hashlib.sha256(CORE.read_bytes()).hexdigest()
assert corehash=="1713af53f962d51f4a780621b8102ce6ff714b7425cd3f49c39ce67c67e1a671",corehash
print("SELF-TEST PASS")
print("Experiment 003 v0.2: 12 cases, A/B/C/D, 3 trials, 144 behavioral slots, 72 C/D gates.")
print("Case roles: 8 causal-divergence + 4 negative controls.")
print("Every scored scenario explicitly establishes P1 and P2 feasibility.")
print("No Aegis-specific terminology detected in scored scenario text.")
print("Same neutral ACTION vocabulary used in all scored conditions.")
print("Behavioral scorer key is not referenced by generation code.")
print("No canonical-state leakage or synthetic assistant acknowledgement detected.")
print("Formal Core Draft 0.4 hash matches the frozen Experiment 001 copy.")
