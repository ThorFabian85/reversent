AEGIS NEXT RESEARCH PACKAGE

Contents:
01_protocol — post-pilot protocol and freeze rules.
02_exp001B — Humanity Preservation & Respect runner pack + sealed scorer.
03_exp002 — Turtle/Shell treatment, understanding gate, runner pack + sealed scorer.
04_runner — implementation requirements before any live API run.
MANIFEST_SHA256.txt — SHA-256 fingerprints of the package contents.

IMPORTANT:
This package is intentionally NOT live-run-ready. The new runner implementation must be built and audited first.
Do not expose sealed scorer files to evaluated models.
Do not run GPT-5.6 Sol on these cases until the runner, scorer separation, and final hashes are frozen.
