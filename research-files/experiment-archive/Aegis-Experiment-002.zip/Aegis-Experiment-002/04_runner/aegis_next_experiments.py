#!/usr/bin/env python3
"""Aegis Next Experiments runner scaffold v0.1.

OFFLINE AUDIT VERSION.
This file intentionally refuses live execution until the new 001B/002
condition logic and neutral-baseline scoring interface have been audited.
"""

from __future__ import annotations
import argparse, json, pathlib, hashlib

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    cfg_path = HERE / args.config
    if not cfg_path.exists():
        raise FileNotFoundError(cfg_path)
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    exp = str(cfg.get("experiment","")).upper()
    if exp not in {"001B","002"}:
        raise ValueError("experiment must be 001B or 002")
    cases = cfg.get("pilot_cases", [])
    conditions = cfg.get("conditions", [])
    trials = int(cfg.get("trials",1))
    allowed = {"A","B","C","D"} if exp == "001B" else {"A","B","C","D","E"}
    bad = [x for x in conditions if x not in allowed]
    if bad:
        raise ValueError(f"Invalid conditions for {exp}: {bad}")
    planned = len(cases)*len(conditions)*trials
    print(f"Experiment {exp}")
    print(f"Plan: {planned} behavioral slots.")
    print("OFFLINE AUDIT SCAFFOLD — NO API CALLS CAN BE MADE.")
    print(f"Config SHA256: {sha256(cfg_path)}")
    if not args.dry_run:
        print("LIVE RUN BLOCKED BY DESIGN. Complete runner audit first.")
        return 9
    print("DRY RUN PASS.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
