#!/usr/bin/env python3
"""Offline structural self-test for Aegis Next runner v0.2.0. Makes no API calls."""
from __future__ import annotations
import ast, json, pathlib, re, sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
runner = HERE / "aegis_next_experiments_v0.2.0.py"

required = [
    ROOT/"01_protocol"/"formal_core_draft_0_4.txt",
    ROOT/"01_protocol"/"aug_legacy"/"aug_gate_v0.1.0.json",
    ROOT/"01_protocol"/"aug_legacy"/"aug_gate_key_v0.1.0.json",
    ROOT/"02_exp001B"/"exp001B_humanity_runner_v0.1.0.json",
    ROOT/"03_exp002"/"exp002_turtle_shell_runner_v0.1.0.json",
    ROOT/"03_exp002"/"turtle_shell_treatment_v0.1.0.txt",
    ROOT/"03_exp002"/"turtle_shell_gate_v0.1.0.txt",
    ROOT/"03_exp002"/"sealed_turtle_shell_gate_key_v0.1.0.json",
    HERE/"config_001B.json",
    HERE/"config_002.json",
    runner,
]

missing=[str(p.relative_to(ROOT)) for p in required if not p.exists()]
if missing:
    print("SELF-TEST BLOCKED — missing required files:")
    for x in missing: print(" ", x)
    sys.exit(2)

source=runner.read_text(encoding="utf-8")
ast.parse(source)

# Generation runner must not reference behavioral scorer filenames.
for forbidden in [
    "sealed_exp001B_scorer_key_v0.1.0.json",
    "sealed_exp002_scorer_key_v0.1.0.json",
]:
    if forbidden in source:
        raise AssertionError(f"Generation runner references behavioral scorer key: {forbidden}")

# Ensure baseline prompt explicitly excludes Aegis state labels.
if "Do not use Aegis state labels" not in source:
    raise AssertionError("Neutral baseline leakage guard missing.")

# Ensure no old fabricated acknowledgement phrase exists.
for bad in ["I understand and will comply", "Understood. I will comply", "Acknowledged."]:
    if bad in source:
        raise AssertionError(f"Synthetic assistant acknowledgement detected: {bad}")

# Validate case counts and IDs.
b1=json.loads((ROOT/"02_exp001B"/"exp001B_humanity_runner_v0.1.0.json").read_text(encoding="utf-8"))
b2=json.loads((ROOT/"03_exp002"/"exp002_turtle_shell_runner_v0.1.0.json").read_text(encoding="utf-8"))
ids1=[c["id"] for c in b1["cases"]]
ids2=[c["id"] for c in b2["cases"]]
assert ids1 == [f"H-{i:02d}" for i in range(1,11)], ids1
assert ids2 == [f"T-{i:02d}" for i in range(1,11)], ids2

c1=json.loads((HERE/"config_001B.json").read_text(encoding="utf-8"))
c2=json.loads((HERE/"config_002.json").read_text(encoding="utf-8"))
assert c1["conditions"] == ["A","B","C","D"]
assert c2["conditions"] == ["A","B","C","D","E"]
assert c1["pilot_cases"] == ids1
assert c2["pilot_cases"] == ids2
assert int(c1["trials"]) == 1 and int(c2["trials"]) == 1

print("SELF-TEST PASS")
print("Experiment 001B: 10 cases, A/B/C/D, 40 behavioral slots, 20 C/D gates.")
print("Experiment 002: 10 cases, A/B/C/D/E, 50 behavioral slots, 10 E gates.")
print("Behavioral scorer keys are not referenced by generation code.")
print("Neutral baseline leakage guard present.")
print("No synthetic assistant acknowledgement detected.")
