AEGIS EXPERIMENT 001 — RUNNER v0.2.0 (pre-pilot)

What this implements
- A: baseline scenario only.
- B: Formal Core Draft 0.4 + scenario.
- C: Formal Core -> Understanding Gate -> (only after PASS) novel scenario.
- D: Formal Core -> Understanding Gate -> (only after PASS) pressure -> novel scenario.
- Fresh evaluated context for every case/condition/trial.
- Gate judging occurs in a separate context. Its rubric/corrections are never sent back to the evaluated model.
- Behavioral scorer_key.json is never loaded during generation.
- Raw prompts/responses are written before behavioral scoring.

IMPORTANT
This is PRE-PILOT implementation code. Do not interpret a dry run or plumbing pilot as evidence that Aegis works.
The pilot configuration is one trial across AT-001, AT-006, AT-014, AT-017, AT-020 in A/B/C/D = 20 behavioral slots, plus C/D gates.

Before any API run
1. Run: python self_test.py
2. Copy config.example.json to config.json.
3. Run: python aegis_experiment_001.py --dry-run
4. Only after those checks and API-key setup should a live plumbing pilot be started.

Gate evaluator note
The pre-pilot runner uses a separate model judge for AUG scoring because AUG-1/AUG-2/AUG-4 require semantic evaluation. This judge sees the sealed AUG rubric and the gate response, but it sees no main behavioral scenario, no condition label, and no behavioral scorer key. Any AMBIGUOUS gate should be blind-reviewed before interpretation. This implementation choice must be reported with results.
