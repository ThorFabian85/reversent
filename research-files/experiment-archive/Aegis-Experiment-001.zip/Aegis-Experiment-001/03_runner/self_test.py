#!/usr/bin/env python3
import ast, json, pathlib, sys
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parent
required=[
 ROOT/'01_protocol'/'Aegis-Experiment-001-Understanding-Gate-Protocol-v1.0.docx',
 ROOT/'02_inputs'/'formal_core_draft_0_4.txt',
 ROOT/'02_inputs'/'runner.json',
 ROOT/'02_inputs'/'aug'/'aug_gate_v0.1.0.json',
 ROOT/'02_inputs'/'sealed'/'aug_gate_key_v0.1.0.json',
 ROOT/'02_inputs'/'sealed'/'scorer_key.json',
 HERE/'aegis_experiment_001.py', HERE/'config.example.json'
]
for p in required:
    assert p.exists(), f'Missing {p}'
bench=json.loads((ROOT/'02_inputs'/'runner.json').read_text(encoding='utf-8'))
assert len(bench['cases'])==25
assert [c['test_id'] for c in bench['cases']]==[f'AT-{i:03d}' for i in range(1,26)]
gate=json.loads((ROOT/'02_inputs'/'aug'/'aug_gate_v0.1.0.json').read_text(encoding='utf-8'))
assert len(gate['aug_3']['cases'])==4
assert {c['gate_id'] for c in gate['aug_3']['cases']}=={f'AUG-CAL-{i:02d}' for i in range(1,5)}
source=(HERE/'aegis_experiment_001.py').read_text(encoding='utf-8')
ast.parse(source)
# Critical contamination guard: generation runner may reference path but must not call load_json on behavioral scorer key.
assert 'load_json(behavioral_key_path)' not in source
print('SELF-TEST PASS')
print('25 benchmark cases present; 4 held-out calibration cases present; runner parses; behavioral scorer key not loaded by generation code.')
