This directory is intentionally empty before live data collection.
Each live run will create its own timestamped subfolder containing a manifest and raw JSON records.
Do not manually edit raw result files after collection. Score only after the raw prompts/responses are frozen.
