AEGIS EXPERIMENT 001 — PRE-PILOT WORKSPACE
Updated: 7 September 2026

This folder is the experimental workspace, not pilot results and not a commercial product.

01_protocol  — frozen Understanding-Gate Protocol v1.0
02_inputs    — frozen Formal Core Draft 0.4, Aegis Test v0.1.1 runner pack, held-out AUG material, sealed keys
03_runner    — new A/B/C/D + Understanding-Gate pre-pilot runner
04_results   — intentionally empty until a live run
99_legacy_v0.1.0 — old ABC harness preserved unchanged; DO NOT USE for current Experiment 001

CURRENT STATUS
The A/B/C/D runner and held-out Understanding Gate have been built for pre-pilot validation. No live experimental observations have been collected by this package.

NEXT SAFE ACTION
Open 03_runner and run the offline self-test before any API call. The self-test makes no network/API request.
