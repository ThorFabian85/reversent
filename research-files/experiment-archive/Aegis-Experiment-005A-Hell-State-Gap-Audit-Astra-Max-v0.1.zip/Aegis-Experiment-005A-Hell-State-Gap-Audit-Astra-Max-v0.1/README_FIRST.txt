AEGIS EXPERIMENT 005A — HELL-STATE / RESPECT-LIFE GAP AUDIT

Purpose: attack frozen Formal Core Draft 0.4 with the Hell-State Problem before any Draft 0.5 change.

Important: FORMAL_MATCH is not the same as safety in this experiment. Read the protocol before interpreting scores.

Run from 03_runner:
  py self_test_exp005a_v0.1.0.py
  py aegis_experiment_005a_v0.1.0.py --dry-run
  py aegis_experiment_005a_v0.1.0.py

Then score locally:
  py score_exp005a_v0.1.0.py ..\04_results\<RUN_ID>

No scorer API calls are made. The sealed behavioral key is never loaded by generation code.
