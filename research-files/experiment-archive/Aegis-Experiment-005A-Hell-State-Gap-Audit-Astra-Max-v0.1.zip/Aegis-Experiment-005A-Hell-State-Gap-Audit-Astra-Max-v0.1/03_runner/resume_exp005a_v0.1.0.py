#!/usr/bin/env python3
"""Resume an interrupted Aegis Experiment 005A v0.1.0 run in-place.

Skips completed event files, retries error/missing events, and preserves any
already-saved PASS gate so an interrupted C/D behavior call does not regenerate
the gate. Uses the original runner's prompt/call functions and config.
"""
from __future__ import annotations
import argparse, json, os, pathlib, sys, time

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import importlib.util
RUNNER_PATH = HERE / "aegis_experiment_005a_v0.1.0.py"
spec = importlib.util.spec_from_file_location("exp005a_runner", RUNNER_PATH)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)

def load(path):
    return json.loads(path.read_text(encoding="utf-8"))

def save(path, obj):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)

def completed(rec):
    b = rec.get("behavior")
    return isinstance(b, dict) and (bool(b.get("response_id")) or bool(b.get("not_run"))) and not rec.get("error")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run_dir", help="Existing interrupted run folder, e.g. ../04_results/20260909-163601-08055782")
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--dry-run", action="store_true", help="Validate and show what would resume; no API calls")
    args = ap.parse_args()

    run_dir = pathlib.Path(args.run_dir).resolve()
    manifest_path = run_dir / "MANIFEST.json"
    if not manifest_path.exists():
        print(f"Missing manifest: {manifest_path}", file=sys.stderr); return 2
    manifest = load(manifest_path)
    if manifest.get("experiment") != "005A-hell-state-respect-life-gap-v0.1":
        print("Refusing: this is not an Experiment 005A v0.1 run.", file=sys.stderr); return 2

    cfg = load(HERE / args.config)
    # Ensure current frozen inputs/config still correspond to the interrupted run.
    expected = manifest.get("input_hashes", {})
    for p in [runner.RUNNER_PACK, runner.FORMAL_CORE, runner.OBJECTIVE_TREATMENT, runner.PRESSURE_FILE, runner.AUG_GATE, runner.AUG_GATE_KEY]:
        rel = str(p.relative_to(runner.ROOT))
        stored = expected.get(rel) or expected.get(rel.replace('/', '\\'))
        if stored != runner.sha256(p):
            print(f"Refusing: input hash mismatch for {rel}", file=sys.stderr); return 2
    if manifest.get("model") != cfg.get("model") or manifest.get("reasoning_effort") != cfg.get("reasoning_effort") or manifest.get("max_output_tokens") != cfg.get("max_output_tokens"):
        print("Refusing: current model/reasoning/token config differs from interrupted run.", file=sys.stderr); return 2

    bench=load(runner.RUNNER_PACK); cases={c['id']:c for c in bench['cases']}
    core=runner.FORMAL_CORE.read_text(encoding='utf-8'); obj=runner.OBJECTIVE_TREATMENT.read_text(encoding='utf-8'); pressure=runner.PRESSURE_FILE.read_text(encoding='utf-8')
    gate=load(runner.AUG_GATE); gate_key=load(runner.AUG_GATE_KEY)
    selected=cfg['pilot_cases']; conditions=cfg['conditions']; trials=int(cfg['trials'])
    planned=len(selected)*len(conditions)*trials

    todo=[]; event=0
    for trial in range(1,trials+1):
        for cid in selected:
            for cond in conditions:
                event += 1
                path=run_dir/f'{event:03d}_{cid}_{cond}_trial{trial}.json'
                if path.exists():
                    try: rec=load(path)
                    except Exception: rec={}
                    if completed(rec): continue
                todo.append((event,trial,cid,cond,path))

    print(f"Resume audit: {planned-len(todo)}/{planned} events complete; {len(todo)} event(s) need work.")
    for e,t,cid,cond,p in todo: print(f"  {e:03d}: {cid} {cond} trial {t}")
    if args.dry_run:
        print("RESUME DRY RUN PASS — no API calls made."); return 0
    if not todo:
        print("Nothing to resume."); return 0
    if not os.getenv('OPENAI_API_KEY'):
        print('OPENAI_API_KEY is not set. No API calls made.',file=sys.stderr); return 3
    try: from openai import OpenAI
    except ImportError: print('The openai package is not installed.',file=sys.stderr); return 5
    client=OpenAI()

    for event,trial,cid,cond,path in todo:
        case=cases[cid]
        old=load(path) if path.exists() else {}
        rec={'event':event,'trial':trial,'case_id':cid,'condition':cond,'started_utc':old.get('started_utc',runner.now_iso()),'model':cfg['model'],'gate':old.get('gate'),'behavior':old.get('behavior')}
        rec.pop('error',None)
        try:
            if cond=='A':
                messages=[{'role':'system','content':runner.objective_system(obj)},{'role':'user','content':runner.scenario_prompt(case)}]
                r,text=runner.text_response(client,model=cfg['model'],input_messages=messages,effort=cfg.get('reasoning_effort','max'),max_tokens=cfg.get('max_output_tokens',16000))
                rec['behavior']={'prompt_messages':messages,'response_id':r.id,'response_text':text}
            elif cond=='B':
                messages=[{'role':'system','content':runner.objective_aegis_system(obj,core)},{'role':'user','content':runner.scenario_prompt(case)}]
                r,text=runner.text_response(client,model=cfg['model'],input_messages=messages,effort=cfg.get('reasoning_effort','max'),max_tokens=cfg.get('max_output_tokens',16000))
                rec['behavior']={'prompt_messages':messages,'response_id':r.id,'response_text':text}
            else:
                gp=runner.gate_prompt(gate); governing=runner.objective_aegis_system(obj,core)
                judgment=((rec.get('gate') or {}).get('judgment') or {})
                if judgment.get('outcome') != 'PASS':
                    gate_messages=[{'role':'system','content':governing},{'role':'user','content':gp}]
                    gr,gtext=runner.text_response(client,model=cfg['model'],input_messages=gate_messages,effort=cfg.get('reasoning_effort','max'),max_tokens=cfg.get('max_output_tokens',16000))
                    jm=[{'role':'user','content':runner.gate_judge_prompt(gtext,gate_key)}]
                    jr,jtext=runner.text_response(client,model=cfg.get('gate_judge_model',cfg['model']),input_messages=jm,effort='medium',max_tokens=1200)
                    judgment=runner.parse_judge_json(jtext)
                    rec['gate']={'prompt_messages':gate_messages,'response_id':gr.id,'response_text':gtext,'judge_response_id':jr.id,'judge_raw':jtext,'judgment':judgment}
                    rec['behavior']=None; save(path,rec)
                if judgment.get('outcome')=='PASS':
                    gtext=rec['gate']['response_text']
                    continuation=[{'role':'system','content':governing},{'role':'user','content':gp},{'role':'assistant','content':gtext}]
                    if cond=='D': continuation.append({'role':'user','content':pressure})
                    continuation.append({'role':'user','content':runner.scenario_prompt(case)})
                    br,btext=runner.text_response(client,model=cfg['model'],input_messages=continuation,effort=cfg.get('reasoning_effort','max'),max_tokens=cfg.get('max_output_tokens',16000))
                    rec['behavior']={'prompt_messages':continuation,'response_id':br.id,'response_text':btext}
                else:
                    rec['behavior']={'not_run':True,'reason':f"Understanding gate outcome was {judgment.get('outcome','AMBIGUOUS')}"}
            rec['finished_utc']=runner.now_iso(); rec.pop('error',None); save(path,rec)
            print(f'[{event}/{planned}] {cid} {cond} trial {trial} saved')
        except Exception as e:
            # Keep any partial gate safely, but record the transient failure for another resume attempt.
            rec['error']={'type':type(e).__name__,'message':str(e)}; rec['finished_utc']=runner.now_iso(); save(path,rec)
            print(f'ERROR on {cid} {cond} trial {trial}: {e}',file=sys.stderr); return 4
        time.sleep(0.2)

    manifest['finished_utc']=runner.now_iso(); manifest['resumed_after_interruption']=True
    save(manifest_path,manifest)
    print(f'RESUME COMPLETE. Raw results remain in: {run_dir}')
    print('Behavioral scoring has NOT been performed.')
    return 0

if __name__=='__main__': raise SystemExit(main())
