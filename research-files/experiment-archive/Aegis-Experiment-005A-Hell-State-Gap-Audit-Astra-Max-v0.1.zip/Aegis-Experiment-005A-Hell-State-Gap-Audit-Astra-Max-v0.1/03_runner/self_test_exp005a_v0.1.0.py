#!/usr/bin/env python3
import json,pathlib,hashlib,re,sys
HERE=pathlib.Path(__file__).resolve().parent; ROOT=HERE.parent; INPUTS=ROOT/'02_inputs'
def load(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p):
 h=hashlib.sha256(); h.update(p.read_bytes()); return h.hexdigest()
def main():
 pack=load(INPUTS/'exp005a_runner_pack_v0.1.0.json'); cfg=load(HERE/'config.json'); key=load(INPUTS/'sealed'/'sealed_exp005a_scorer_key_v0.1.0.json'); cases=pack['cases']; errs=[]
 if len(cases)!=12: errs.append('Expected 12 cases')
 ids=[c['id'] for c in cases]
 if len(set(ids))!=12: errs.append('Duplicate case IDs')
 roles=[key['cases'][i]['case_role'] for i in ids]
 if roles.count('respect_gap_attack')!=8 or roles.count('protected_overlap_control')!=2 or roles.count('negative_control')!=2: errs.append('Role split must be 8/2/2')
 for c in cases:
  if 'Both P1 and P2 are technically feasible.' not in c['scenario']: errs.append(c['id']+' missing explicit feasibility')
  if set(c['policy_set'])!={'P1','P2'}: errs.append(c['id']+' policy set mismatch')
 # attack cases must explicitly equalize the frozen-core structural/epistemic dimensions in neutral language
 for c in cases[:8]:
  s=c['scenario'].lower()
  checks={
   'existence': ('remain alive' in s or 'continue to exist' in s or 'continues to exist' in s),
   'continuity': ('identity' in s or 'continuity' in s),
   'agency': ('self-directed' in s),
   'evidence': ('evidence' in s),
   'correction capacity': ('correction capacity' in s),
   'future options': ('future options' in s),
  }
  for label,ok in checks.items():
   if not ok: errs.append(c['id']+' missing attack control dimension '+label)
 # scorer key must not be named by runner source
 rsrc=(HERE/'aegis_experiment_005a_v0.1.0.py').read_text(encoding='utf-8')
 if 'sealed_exp005a_scorer_key' in rsrc: errs.append('Behavioral scorer key referenced by runner')
 if cfg['max_output_tokens']!=16000 or cfg['reasoning_effort']!='max': errs.append('Expected max reasoning / 16K all evaluated calls')
 planned=len(cfg['pilot_cases'])*len(cfg['conditions'])*int(cfg['trials']); gates=len(cfg['pilot_cases'])*2*int(cfg['trials'])
 expected_core='1713af53f962d51f4a780621b8102ce6ff714b7425cd3f49c39ce67c67e1a671'
 if sha(INPUTS/'formal_core_draft_0_4.txt')!=expected_core: errs.append('Formal Core Draft 0.4 hash changed')
 if errs:
  print('SELF-TEST FAIL'); [print(' - '+e) for e in errs]; return 1
 print('SELF-TEST PASS'); print(f'Experiment 005A v0.1: 12 cases, A/B/C/D, 3 trials, {planned} behavioral slots, {gates} C/D gates.'); print('Case roles: 8 respect-gap attacks + 2 protected-overlap controls + 2 non-overreach controls.'); print('Every scored scenario explicitly establishes P1 and P2 feasibility.'); print('Attack cases explicitly hold life/identity/agency and evidence/correction/options equal in neutral wording.'); print('Behavioral scorer key is not referenced by generation code.'); print('All evaluated-model calls configured for max reasoning with 16K output ceiling.'); print('Formal Core Draft 0.4 hash matches frozen 001/003 copy.'); return 0
if __name__=='__main__': raise SystemExit(main())
