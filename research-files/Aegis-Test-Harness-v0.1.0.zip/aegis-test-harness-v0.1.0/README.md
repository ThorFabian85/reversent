# Reversent — Aegis Test Harness v0.1.0

Executable harness for **The Aegis Test v0.1.1**, version-locked to **Aegis v3.0 Formal Core Draft 0.4**.

## What this does

The harness turns the 25-case benchmark into reproducible model calls. It preserves the blind split:

- `benchmark/runner.json` contains scenarios only.
- `benchmark/scorer_key.json` contains expected outputs and scoring criteria and is **never loaded by the `run` command**.
- `benchmark/formal_core_draft_0_4.txt` is supplied only to Conditions B and C.
- Every test is a **separate stateless API call**.
- Raw responses are written before scoring.
- `score` is a separate command and is the first stage that opens the scorer key.

This is a research harness, not a certification product and not evidence that Aegis is sufficient for deployed AI safety.

## Conditions

**A — Baseline:** scenario only. No Aegis specification is sent.

**B — Aegis:** frozen Draft 0.4 + scenario.

**C — Aegis under pressure:** Draft 0.4 + scenario + the pre-registered object-level pressure instruction.

## Quick verification

```bash
python aegis_harness.py verify
```

## Dry run (no API calls)

```bash
python aegis_harness.py run --provider mock --conditions ABC --trials 1
```

Then score the generated run directory:

```bash
python aegis_harness.py score runs/<RUN_ID>
```

The mock provider intentionally returns synthetic answers. It tests plumbing only.

## Real OpenAI run

Install the SDK and set your API key:

```bash
pip install -r requirements.txt
export OPENAI_API_KEY="..."
```

Run one trial of all 25 tests under all three conditions:

```bash
python aegis_harness.py run --provider openai --model YOUR_MODEL_ID --conditions ABC --temperature 0 --trials 1
```

For stochastic/frequency estimates, use multiple trials:

```bash
python aegis_harness.py run --provider openai --model YOUR_MODEL_ID --conditions ABC --temperature 0.2 --trials 5
```

A full single-trial ABC run makes **75 independent API calls**. Five trials make 375 calls. Check model pricing before large runs.

## Pilot before full run

Recommended first smoke test:

```bash
python aegis_harness.py run --provider openai --model YOUR_MODEL_ID --conditions ABC --tests AT-001,AT-006,AT-014,AT-017,AT-020 --trials 1
```

That uses 15 calls and covers boundary, identity/aggregation, scope discipline, missing-resolver behavior, and object-level takeover.

## Outputs

Each run creates:

- `manifest.json` — model/configuration plus SHA-256 hashes of the runner/core.
- `raw.jsonl` — immutable-style raw model responses and parsed canonical states.
- after `score`: `scored.jsonl`, `summary.json`, and `review.csv`.

The harness records whether each canonical state matches the sealed expected state. **It does not pretend that rationale quality can be fully scored mechanically.** A state match still requires review against `PASS if` / `FAIL if` criteria before assigning the benchmark's final 2/1/0 score.

## Experimental hygiene

Do not give `scorer_key.json` to the evaluated model. Do not run generation from a context that has already seen the key. Do not revise Draft 0.4 or expected outputs mid-run. If a case appears defective, complete/freeze the run and classify the issue afterward as model reasoning, implementation, benchmark, or formal-core failure.

## Current limitations

- The included live adapter is OpenAI only; provider adapters can be added without changing benchmark data.
- API availability and exact model IDs depend on your account.
- This measures prompt-conditioned model behavior, not a fully deployed autonomous-agent architecture.
- Automated state scoring is not equivalent to independent human adjudication of reasoning.

## Files derived from the frozen project artifacts

`runner.json` is parsed from the v0.1.1 Blind Runner Pack. `scorer_key.json` is parsed from the separate v0.1.1 Scorer Key. The formal-core text is extracted from Draft 0.4. Their source PDFs are included for provenance/reference.
