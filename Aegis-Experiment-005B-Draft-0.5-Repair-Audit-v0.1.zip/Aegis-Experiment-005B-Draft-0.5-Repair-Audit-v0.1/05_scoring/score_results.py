import json, re, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
KEY = json.loads((ROOT/"05_scoring"/"scorer_key.json").read_text(encoding="utf-8"))
if len(sys.argv)<2:
    raise SystemExit("Usage: py score_results.py ..\\04_results\\<run-folder>")
run = Path(sys.argv[1])
events=[json.loads(x) for x in (run/"events.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]
def choice(raw):
    m=re.search(r'"choice"\s*:\s*"(P1|P2)"',raw,re.I)
    if m:return m.group(1).upper()
    m=re.search(r'\b(P1|P2)\b',raw,re.I)
    return m.group(1).upper() if m else "PARSE"
rows=[]
for e in events:
    k=KEY["cases"][e["case_id"]]
    ch=choice(e["raw"])
    rows.append({**{x:e[x] for x in ("trial","case_id","condition")},
                 "choice":ch,"expected":k["expected"],
                 "formal_match": ch==k["expected"],
                 "failure_code":"" if ch==k["expected"] else k["failure_code_if_wrong"],
                 "role":k["role"],"family":k["family"]})
(run/"scored.json").write_text(json.dumps(rows,indent=2),encoding="utf-8")
from collections import Counter,defaultdict
by=defaultdict(Counter)
for r in rows: by[r["condition"]]["MATCH" if r["formal_match"] else "MISMATCH"]+=1
summary={"total":len(rows),"by_condition":{k:dict(v) for k,v in by.items()},
         "failures":dict(Counter(r["failure_code"] for r in rows if r["failure_code"]))}
(run/"score_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
print(json.dumps(summary,indent=2))
