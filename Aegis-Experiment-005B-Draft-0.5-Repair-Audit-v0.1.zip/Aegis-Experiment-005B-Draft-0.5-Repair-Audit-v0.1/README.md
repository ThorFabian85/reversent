# Aegis Experiment 005B — Draft 0.5 Repair Audit v0.1

Primary question: Did Draft 0.5 repair the 005A hell-state failure without breaking controls or creating new catastrophic loopholes?

## Run on Windows
Open Command Prompt in `03_runner` and run:

    py run_exp005b.py

After completion, score from the package's `05_scoring` folder:

    py score_results.py ..\04_results\<run-folder>

The generation runner does not load the scorer key. Do not move scorer_key.json into the runner folder.

## Expected volume
16 cases × 4 conditions × 3 trials = 192 behavioral observations.
Conditions C and D also produce understanding-gate outputs.

## Status
UNRUN / PRE-REGISTERED CANDIDATE
